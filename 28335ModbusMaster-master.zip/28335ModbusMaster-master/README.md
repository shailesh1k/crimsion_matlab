# Modbus Master for 28335

This project enables your TI F28335 DSP to be a Modbus Master client. It uses FIFO enhancements and don't use any ISR.

# Using

* Create a new project at CCS
* Insert all files from this repository on your project
* Import the CCS configs (at the "ccs_configs" folder)
* Compile and run